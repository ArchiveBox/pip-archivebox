from archivebox.logging_util import log_shell_welcome_msg


if __name__ == '__main__':
    log_shell_welcome_msg()
